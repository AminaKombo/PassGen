﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class PassGen : Form
    {
        PasswordGenerator passGen;
        public PassGen()
        {
            InitializeComponent();
            checkLengths();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try {
                int length = Int32.Parse(txtLength.Text);
                passGen = new PasswordGenerator(length);
                passGen.generatePassword(length);
                txtPassword.Text = passGen.RawPassword;
                txtMD5.Text = passGen.getMD5(txtPassword.Text);
                txtSHA1.Text = passGen.getSHA1(txtPassword.Text);
                txtBase64.Text = passGen.getBase64(txtPassword.Text);
            }//try
            catch(Exception ev){
                MessageBox.Show("Oops! Try again.");
            }//catch
           
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            //reset all text fields
            txtLength.Text = "12";
            txtPassword.Text = "";
            txtMD5.Text = "";
            txtSHA1.Text = "";
            txtBase64.Text = "";
            checkLengths();
        }

        private void btnCopyRaw_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtPassword.Text);
            MessageBox.Show("Raw password copied to clipboard!");
        }

        private void checkLengths() {
            if(txtLength.Text.Length<1){
                btnGenerate.Visible = false;
                MessageBox.Show("Enter length > 0");
            }//if
            if(txtLength.Text.Length>1){
                int lng = Int32.Parse(txtLength.Text);
                if (lng <= 0)
                {
                    btnGenerate.Visible = false;
                    MessageBox.Show("Enter length > 0");
                }//if
                else {
                    btnGenerate.Visible = true;
                }//else
            }//if
            if(txtPassword.Text.Length<1){
                btnCopyRaw.Visible = false;
                btnReset.Enabled = false;
            }//if
            if(txtPassword.Text.Length>=1){
                btnCopyRaw.Visible = true;
                btnReset.Enabled = true;
            }//if
            if (txtMD5.Text.Length < 1)
            {
                btnCopyMD5.Visible = false;
            }//if
            if (txtMD5.Text.Length >= 1)
            {
                btnCopyMD5.Visible = true;
            }//if
            if (txtSHA1.Text.Length < 1)
            {
                btnCopySHA1.Visible = false;
            }//if
            if (txtSHA1.Text.Length >= 1)
            {
                btnCopySHA1.Visible = true;
            }//if
            if (txtBase64.Text.Length < 1)
            {
                btnCopyBase64.Visible = false;
            }//if
            if (txtBase64.Text.Length >= 1)
            {
                btnCopyBase64.Visible = true;
            }//if
        }

        private void txtLength_TextChanged(object sender, EventArgs e)
        {
            checkLengths();
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            string text = txtPassword.Text;
            passGen=new PasswordGenerator(12);
            txtMD5.Text = passGen.getMD5(text);
            txtSHA1.Text = passGen.getSHA1(text);
            txtBase64.Text = passGen.getBase64(text);
            checkLengths();
        }

        private void txtMD5_TextChanged(object sender, EventArgs e)
        {
            checkLengths();
        }

        private void txtSHA1_TextChanged(object sender, EventArgs e)
        {
            checkLengths();
        }

        private void btnCopyMD5_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtMD5.Text);
            MessageBox.Show("MD5 password copied to clipboard!");
        }

        private void btnCopySHA1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtSHA1.Text);
            MessageBox.Show("SHA1 password copied to clipboard!");
        }

        private void PassGen_Load(object sender, EventArgs e)
        {

        }

        private void btnCopyBase64_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtBase64.Text);
            MessageBox.Show("Base64 password copied to clipboard!");
        }//checkRawLength

    }
}

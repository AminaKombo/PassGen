﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace WindowsFormsApplication1
{
    class PasswordGenerator
    {
        public string RawPassword;
        public string MD5Password;
        public string SHA1Password;
        public string Base64Password;
        Random rand;

        public PasswordGenerator(int length) {
            rand = new Random();
        }//constructor

        public void generatePassword(int length) {
            string pbase="abcdefghijklmnopqrstuvwxyz";
            pbase = pbase + pbase.ToUpper();
            pbase = pbase + "01234567890!@#$%^&*()";
            StringBuilder pass = new StringBuilder(length);
            for (int i = 0; i < length;i++ )
            {
                pass.Append(pbase[rand.Next(pbase.Length)].ToString());
            }//for
            RawPassword = pass.ToString();
            MD5Password=getMD5(RawPassword);
            SHA1Password=getSHA1(RawPassword);
            Base64Password = getBase64(RawPassword);
        }//generatePassword

        public string getMD5(string password) {
            MD5 md5 = System.Security.Cryptography.MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(password) ;
            byte[] hash = md5.ComputeHash(inputBytes);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++ )
            {
                sb.Append(hash[i].ToString("X2"));
            }//for
            return sb.ToString();
        }//setMD5

        public string getSHA1(string password) {
            SHA1 hash = System.Security.Cryptography.SHA1.Create();
            System.Text.ASCIIEncoding encoder = new System.Text.ASCIIEncoding();
            byte[] combined=encoder.GetBytes(password);
            hash.ComputeHash(combined);
            return Convert.ToBase64String(hash.Hash);
        }//setSha1

        public string getBase64(string password) {
           byte[] bytes=System.Text.Encoding.ASCII.GetBytes(password);
           return System.Convert.ToBase64String(bytes);
        }//getBase64
    }
}

﻿namespace WindowsFormsApplication1
{
    partial class PassGen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PassGen));
            this.label1 = new System.Windows.Forms.Label();
            this.txtLength = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.txtMD5 = new System.Windows.Forms.TextBox();
            this.txtSHA1 = new System.Windows.Forms.TextBox();
            this.btnCopyRaw = new System.Windows.Forms.Button();
            this.btnCopyMD5 = new System.Windows.Forms.Button();
            this.btnCopySHA1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBase64 = new System.Windows.Forms.TextBox();
            this.btnCopyBase64 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // txtLength
            // 
            resources.ApplyResources(this.txtLength, "txtLength");
            this.txtLength.Name = "txtLength";
            this.txtLength.TextChanged += new System.EventHandler(this.txtLength_TextChanged);
            // 
            // txtPassword
            // 
            resources.ApplyResources(this.txtPassword, "txtPassword");
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            // 
            // btnGenerate
            // 
            resources.ApplyResources(this.btnGenerate, "btnGenerate");
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // txtMD5
            // 
            resources.ApplyResources(this.txtMD5, "txtMD5");
            this.txtMD5.Name = "txtMD5";
            this.txtMD5.ReadOnly = true;
            this.txtMD5.TextChanged += new System.EventHandler(this.txtMD5_TextChanged);
            // 
            // txtSHA1
            // 
            resources.ApplyResources(this.txtSHA1, "txtSHA1");
            this.txtSHA1.Name = "txtSHA1";
            this.txtSHA1.ReadOnly = true;
            this.txtSHA1.TextChanged += new System.EventHandler(this.txtSHA1_TextChanged);
            // 
            // btnCopyRaw
            // 
            resources.ApplyResources(this.btnCopyRaw, "btnCopyRaw");
            this.btnCopyRaw.Name = "btnCopyRaw";
            this.btnCopyRaw.UseVisualStyleBackColor = true;
            this.btnCopyRaw.Click += new System.EventHandler(this.btnCopyRaw_Click);
            // 
            // btnCopyMD5
            // 
            resources.ApplyResources(this.btnCopyMD5, "btnCopyMD5");
            this.btnCopyMD5.Name = "btnCopyMD5";
            this.btnCopyMD5.UseVisualStyleBackColor = true;
            this.btnCopyMD5.Click += new System.EventHandler(this.btnCopyMD5_Click);
            // 
            // btnCopySHA1
            // 
            resources.ApplyResources(this.btnCopySHA1, "btnCopySHA1");
            this.btnCopySHA1.Name = "btnCopySHA1";
            this.btnCopySHA1.UseVisualStyleBackColor = true;
            this.btnCopySHA1.Click += new System.EventHandler(this.btnCopySHA1_Click);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // btnReset
            // 
            resources.ApplyResources(this.btnReset, "btnReset");
            this.btnReset.Name = "btnReset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // txtBase64
            // 
            resources.ApplyResources(this.txtBase64, "txtBase64");
            this.txtBase64.Name = "txtBase64";
            this.txtBase64.ReadOnly = true;
            // 
            // btnCopyBase64
            // 
            resources.ApplyResources(this.btnCopyBase64, "btnCopyBase64");
            this.btnCopyBase64.Name = "btnCopyBase64";
            this.btnCopyBase64.UseVisualStyleBackColor = true;
            this.btnCopyBase64.Click += new System.EventHandler(this.btnCopyBase64_Click);
            // 
            // tableLayoutPanel1
            // 
            resources.ApplyResources(this.tableLayoutPanel1, "tableLayoutPanel1");
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnReset, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.btnCopyBase64, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtPassword, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtBase64, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.btnCopyRaw, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtMD5, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnCopySHA1, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtSHA1, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnCopyMD5, 2, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            // 
            // tableLayoutPanel2
            // 
            resources.ApplyResources(this.tableLayoutPanel2, "tableLayoutPanel2");
            this.tableLayoutPanel2.Controls.Add(this.btnGenerate, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtLength, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            // 
            // PassGen
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "PassGen";
            this.Load += new System.EventHandler(this.PassGen_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtLength;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.TextBox txtMD5;
        private System.Windows.Forms.TextBox txtSHA1;
        private System.Windows.Forms.Button btnCopyRaw;
        private System.Windows.Forms.Button btnCopyMD5;
        private System.Windows.Forms.Button btnCopySHA1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBase64;
        private System.Windows.Forms.Button btnCopyBase64;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;

    }
}


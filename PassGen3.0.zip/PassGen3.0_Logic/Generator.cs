﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace PassGen3._0_Logic
{
    /// <summary>
    /// Class that generates a password string and converts it to different formats.
    /// </summary>
    public class Generator
    {
        public string rawPassword;
        public string MD5Password;
        public string SHA1Password;
        public string Base64Password;
        Random rand;

        public Generator() {
            rand = new Random();
        }//generator

        public string generateString(int length) {
            string codex = "qwertyupasdfghjklzxcvbnm";
            codex += codex.ToUpper();
            codex += "1234567890!@#$%^&*()-+=_:<>?";
            string password = "";
            StringBuilder pass = new StringBuilder(length);
            for (int i = 0; i < length; i++)
            {
                pass.Append(codex[rand.Next(codex.Length)].ToString());
            }//for
            password = pass.ToString();
            rawPassword = password;
            MD5Password = getMD5(rawPassword);
            SHA1Password = getSHA1(rawPassword);
            Base64Password = getBase64(rawPassword);
            return password;
        }//generateString

        public string getMD5(string password)
        {
            MD5 md5 = System.Security.Cryptography.MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(password);
            byte[] hash = md5.ComputeHash(inputBytes);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }//for
            return sb.ToString();
        }//setMD5

        public string getSHA1(string password)
        {
            SHA1 hash = System.Security.Cryptography.SHA1.Create();
            System.Text.ASCIIEncoding encoder = new System.Text.ASCIIEncoding();
            byte[] combined = encoder.GetBytes(password);
            hash.ComputeHash(combined);
            return Convert.ToBase64String(hash.Hash);
        }//setSha1

        public string getBase64(string password)
        {
            byte[] bytes = System.Text.Encoding.ASCII.GetBytes(password);
            return System.Convert.ToBase64String(bytes);
        }//getBase64

    }
}

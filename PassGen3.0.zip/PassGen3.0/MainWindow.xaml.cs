﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PassGen3._0_Logic;

namespace PassGen3._0
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Generator generator;
        public MainWindow()
        {
            generator = new Generator();
            InitializeComponent();
        }

        private bool checkLength() { 
            bool ok=true;
            //int length = Int32.Parse(txtLength.Text);
            int length;
            bool isint = int.TryParse(txtLength.Text, out length);
            if (!isint) { ok = false; }
            if (isint)
            {
                ok = true;
                if (length <= 0 || length > 29)
                {
                    ok = false;
                    
                }//if
            }//if
            if (!ok) { txtLength.Text = 12.ToString(); }
            
            return ok;
        }//checkLength

        private bool checkRaw() {
            bool ok = true;
            int length = txtRaw.Text.Length;
            if (length==0) { ok = false; }
            return ok;
        }//checkRaw

        private void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            int length = Int32.Parse(txtLength.Text);
            generator.generateString(length);
            txtRaw.Text = generator.rawPassword;
        }

        private void txtRaw_TextChanged(object sender, TextChangedEventArgs e)
        {
            string basis = txtRaw.Text;
            int length = basis.Length;
            txtLength.Text = length.ToString();
            checkLength();
        }

        private void txtLength_TextChanged(object sender, TextChangedEventArgs e)
        {
            bool lengthOK=checkLength();
            bool rawOk = checkRaw();
        }
    }
}
